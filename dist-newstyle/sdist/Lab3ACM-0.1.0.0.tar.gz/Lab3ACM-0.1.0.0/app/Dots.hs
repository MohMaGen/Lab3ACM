module Dots (Dot (Dot)) where

newtype Dot = Dot (Double, Double)

