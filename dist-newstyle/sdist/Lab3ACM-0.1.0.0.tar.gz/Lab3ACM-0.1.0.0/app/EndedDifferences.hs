module EndedDifferences (printTable) where

import Dots

import Formatting


printTable :: [Dot] -> IO ()
printTable [] = putStrLn ""
printTable (Dot (x, y):ds) = do
    fprintLn ("Person's name is " % text % " and age is " % int) "Dave" 54;
    printTable ds

